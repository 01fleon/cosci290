/*
	Mike Plata
	CoSci 290

	Knife Class
*/

public class Knife extends Weapon

public class Knife{
	
	public Knife() {
		
		//assigns a value to the name property
		this.name = "Knife";
		
		//assigns a value to the type property
		this.type = "Knife";
		
		//assigns a value to the attack property
		this.attack = 6;
	}
}