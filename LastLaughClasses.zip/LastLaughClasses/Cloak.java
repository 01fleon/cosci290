/*
	Mike Plata
	CoSci 290

	Cloak class
*/

public class Cloak extends Armor

public class Cloak{
	
	//the Cloak class has one default constructor
	public Cloak() {
		
		//assigns the indicated string to the name property
		this.name = "Cloak";
		
		//assigns the indicated strong to the type property
		this.type = "Cloak";
		
		//assigns the indicated value to the defense property
		this.defense = 4;
	}
}