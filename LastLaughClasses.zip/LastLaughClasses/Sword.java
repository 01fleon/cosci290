/*
	Mike Plata
	CoSci 290

	Sword Class
*/

public class Sword extends Weapon

public class Sword{
	
	public Sword() {
		
		//assigns a value to the name property
		this.name = "Sword";
		
		//assigns a value to the type property
		this.type = "Sword";
		
		//assigns a value to the attack property
		this.attack = 8;
	}
}